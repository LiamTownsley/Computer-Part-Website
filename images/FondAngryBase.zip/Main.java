import java.util.Scanner ;

class Main {

  public static void main(String[] args) {
    // bicycleTest() ;
    carTest() ;
  }

  public static void bicycleTest()
  {
     Bicycle bicycle1 = new Bicycle( 0, 0, 1 ) ;
     System.out.println("Defualt Bicycle 1 speed: " + bicycle1.getSpeed());
     for(int i = 1; i < 7; i++) {
       bicycle1.speedUp(10);
       System.out.println("(" + i + ") Bicycle 1 speed increased by 10, speed is now: " + bicycle1.getSpeed());
     }

     Bicycle bicycle2 = new Bicycle(0,50,0);
     System.out.println("Defualt Bicycle 2 speed: " + bicycle2.getSpeed());
     for(int i = 1; i < 7; i++) {
       bicycle2.applyBrake(10);
       System.out.println("(" + i + ") Bicycle 2 speed decreased by 10, speed is now: " + bicycle2.getSpeed());
     }
  }

  public static void carTest()
  {
    Car car1 = new Car("Lambo", 0, 1);
    System.out.println(car1.toString());
  }

}