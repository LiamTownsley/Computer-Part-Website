import java.util.StringJoiner;

public class Car {
    private String modelName;
    private int currentSpeed;
    private int currentGear;
    private final int topGear = 6;
    private final int topSpeed = 255;
    private int lowestGear = 1;
        
    public Car(String mdlName, int curSpeed, int curGear){
        modelName = mdlName;
        currentSpeed = curSpeed;
        currentGear = curGear;
    }
        
    public int getCurentGear() {
      return currentGear;
    }

    public void shiftUp() {
      if(currentGear++ < topGear) {
        currentGear++;
      } else {
        currentGear = topGear;
      }
    }

    public void shiftDown() {
      if(currentGear-- >= lowestGear) {
        currentGear--;
      } else {
        currentGear = 1;
      }
    }

    public void speedUp(int increment) {
      if((currentSpeed + increment) <= topSpeed) {
        currentSpeed = currentSpeed + increment;
      } else {
        currentSpeed = topSpeed;
      }
    }

    public void speedDown(int decrement) {
      if((currentSpeed - decrement) >= 0) {
        currentSpeed = currentSpeed - decrement;
      } else {
        currentSpeed = 0;
      }
    }

    public String toString() {
      String model = "Model: ".concat(modelName);
      String speed = "Speed: ".concat(Integer.toString(currentSpeed));
      String gear = "Gear: ".concat(Integer.toString(currentGear));
      
      StringJoiner sj = new StringJoiner(" - ")
        .add(model)
        .add(speed)
        .add(gear);
      return sj.toString();
    }

}